﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TecheartSln.Core.Scene;
using $safeprojectname$.Domain;

namespace $safeprojectname$.Scene
{
    public class QuestionEditorScence: BaseScene
    {
        public IList<Question> QuestionList { get; set; }
    }
}
