﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.ViewModel
{
    /// <summary>
    /// 只为了扩展命名空间该类在 ViewModel文件夹下有值之后 即可删除
    /// </summary>
    public class Class1
    {
    }
}
